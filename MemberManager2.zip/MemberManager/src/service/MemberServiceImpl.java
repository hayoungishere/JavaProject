package service;

import vo.MemberVo;

public interface MemberServiceImpl {
	public int registMember();
	public void  selectMembers();
	public void selectMember();
	public int updateMember();
	public int deleteMember();
	
}
